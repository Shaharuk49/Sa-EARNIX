<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('user_bonus_video_progress', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->foreignId('bonus_section_video_id')->constrained()->cascadeOnDelete();
            $table->boolean('is_watched')->default(false);
            $table->timestamp('watched_at')->nullable();
            $table->timestamps();

            $table->unique(['user_id', 'bonus_section_video_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('user_bonus_video_progress');
    }
};